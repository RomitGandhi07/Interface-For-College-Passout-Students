<?php include_once"header.php" ?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Full Width Pics - Start Bootstrap Template</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/full-width-pics.css" rel="stylesheet">

	
	<script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	
	<style>
	.verified_text
	{
		margin-top:22%;
		margin-left:33%;
		font-size:28px;
	}
	
	.btn-continue
	{
		margin-top:2%;
		margin-left:85%;
	}
	
	</style>
	</head>
	
	<body>
	
	<div class="container">
	<div class="row"> 
	
		<div class="verified_text">
	
		<p>Your Email Id is Verified.</p>
	</div>
	
	
	<div class="col-sm-6 controls">
                
				<a  href="index.php" class="btn btn-success btn-continue">Continue</a>
				</div>
	
	</div>
	</div>
	</body>
</html>
