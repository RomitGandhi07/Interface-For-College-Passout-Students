<html>
	<head>
	
	<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/full-width-pics.css" rel="stylesheet">

<style>
.footer_container
{
	float:left;
	width:25%;
	height:30%;
	background-color: #850019 !important;
	
	color:white;
	margin-top:3%;
	}
	
	.li_text{
		color:white;
	}
	
	.f_container
	{
		margin-top:5%;
	}
	
</style>
</head>
<body>
<div class="f_container">
<div class="footer_container" style="margin-left:0.1%">

	<div class="col-lg-12 footer-brand animated fadeInLeft">
	
            	<br/><h4>ADDRESS</h4>
				
                <p>Ahmedabad City
					401, Plasma Complex, Bodakdev,
					Gujarat-380005</p>
			
        <p>&copy; 2018 eduinterfaces . All Rights Reserved </p>
            </div>

</div>

<div class="footer_container">


<div class="col-lg-12 footer-nav animated fadeInUp"> 
            	
            	<div class="col-md-14" style="margin-top:12%;">
				
                    <ul class="list" >
                        <li class="li_text"><a href="#"><font color="white" ><h5>About Us</h5></font></a></li>
                        <li class="li_text"><a href="#"><font color="white" ><h5>Contacts</h5></font></a></li>
                        <li class="li_text"><a href="#"><font color="white" ><h5>Terms & Condition</h5></font></a></li>
                        <li class="li_text"><a href="#"><font color="white" ><h5>Privacy Policy</h5></font></a></li>
                    </ul>
                </div>
            </div>

</div>

<div class="footer_container">

<div class="col-lg-12 footer-social animated fadeInDown">
            	<br/><h4>Follow Us</h4>
            	<ul>
                	<li class="li_text"><a href="#"><font color="white">Facebook</font></a></li>
                	<li class="li_text"><a href="#"><font color="white">Twitter</font></a></li>
                	<li class="li_text"><a href="#"><font color="white">Instagram</font></a></li>
                	<li class="li_text"><a href="#"><font color="white">Google+</font></a></li>
                </ul>
            </div>


</div>

<div class="footer_container" style="width:24%">
<div class="col-lg-12 footer-ns animated fadeInRight">
            	<br/><h4>Telephone:</h4>
                <p>1800 200 200</p>
                <br/>
				<p>
                    Email : <a class="mail" href="mailto:mail@example.com"><font color="white">info@eduinterfaces.com</font>
                 </p>
            </div>

</div>


</div>
</body>
</html>