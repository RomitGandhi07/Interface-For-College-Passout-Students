<?php

    //DB details
    $dbHost     = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName     = 'db1';
    
    //Create connection and select DB
    $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    
    //Check connection
    if($db->connect_error){
       die("Connection failed: " . $db->connect_error);
    }
    
    //Get image data from database
    $result = $db->query("SELECT created,id,image FROM images");
    
    if($result->num_rows > 0){
      //  $imgData = $result->fetch_assoc();
        
echo "<table border='1'>
<tr>
<th>CREATED</th>
<th>ID</th>
<th>Image</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row[0] . "</td>";
echo "<td>" . $row[1] . "</td>";
//echo "<td>" . $row[2] . "</td>";
$a=base64_encode($row[2]);
//data:text/html;base64,"
//echo "<td><img src="."data:text/html;base64," .$a . " height=100 //width =100 /></td>";
//echo '<td><img src="data:image/jpg;base64,' .  base64_encode
//($row[2])  . '"  height=100 width=100/></td>';
//$image = imagecreatefromstring(base64_encode($row[2] )); 

echo "<td>" ."<img height=500 width=900 src='data:text/html;base64,".$a." '/>". "</td>";
echo "</tr>";
}
echo "</table>";

}
 //print $row['data'];
        //Render image
      //  header("Content-type: image/jpg"); 
       // echo $imgData['image']; 
?>

<? PHP
    }else{
        echo 'Image not found...';
    }

?>