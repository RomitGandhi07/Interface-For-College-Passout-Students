<?php

    $dbHost = 'localhost';       
        $dbUsername = 'root';
        $dbPassword = '';
        $dbName     = 'db1';
        
?>