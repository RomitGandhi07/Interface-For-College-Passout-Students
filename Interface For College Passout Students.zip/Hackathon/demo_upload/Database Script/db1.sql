-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2018 at 08:41 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db1`
--

-- --------------------------------------------------------

--
-- Table structure for table `folder_images`
--

CREATE TABLE `folder_images` (
  `id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `image` varchar(100) NOT NULL,
  `User_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `folder_images`
--

INSERT INTO `folder_images` (`id`, `created`, `image`, `User_Name`) VALUES
(1, '2018-01-19 06:28:16', 'abcd.JPG', 'a'),
(2, '2018-01-19 06:29:07', 'redmi.JPG', 'a'),
(3, '2018-01-19 06:30:21', 'red2.JPG', 'b'),
(4, '2018-01-19 06:34:06', 'Capture.JPG', 'a'),
(5, '2018-01-19 06:38:28', 'Desert.jpg', 'a'),
(6, '2018-01-19 06:40:45', 'Jellyfish.jpg', 'a'),
(7, '2018-01-19 08:22:33', 'Tulips.jpg', 'a'),
(8, '2018-01-19 08:26:09', 'Hydrangeas.jpg', 'c'),
(9, '2018-01-19 08:32:11', 'Letter_Head_Hackathon_2017.jpg', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image` longblob NOT NULL,
  `created` datetime NOT NULL,
  `User_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE `login_master` (
  `Id` int(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `User_Name` varchar(100) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_master`
--

INSERT INTO `login_master` (`Id`, `Email`, `User_Name`, `Password`) VALUES
(1, 'a@g.com', 'a', 'a'),
(2, 'b@g.com', 'b', 'b'),
(3, 'c@g.com', 'c', 'c');

-- --------------------------------------------------------

--
-- Table structure for table `output_images`
--

CREATE TABLE `output_images` (
  `id` int(11) NOT NULL,
  `imageType` varchar(100) NOT NULL,
  `imageData` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t1`
--

CREATE TABLE `t1` (
  `e_no` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t1`
--

INSERT INTO `t1` (`e_no`, `name`) VALUES
(1, 'ww');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `folder_images`
--
ALTER TABLE `folder_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_master`
--
ALTER TABLE `login_master`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `output_images`
--
ALTER TABLE `output_images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `folder_images`
--
ALTER TABLE `folder_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `login_master`
--
ALTER TABLE `login_master`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `output_images`
--
ALTER TABLE `output_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
