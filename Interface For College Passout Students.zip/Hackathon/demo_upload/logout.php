<?php
session_start();
if(session_destroy()) // session_Unset()
{
	// Unset($_SESSION['login_user'])
header("Location: login.php");
}
?>