<?php
session_start();
if(isset($_SESSION['login_user']))
{
$user=$_SESSION['login_user'];
}
else
{

    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html>
<body>

    <form method="post" enctype="multipart/form-data">
    <TABLE border = 1><tr><td> WELCOME : <?php echo $user; ?></td><td><a href="logout.php">Logout</a></td></tr>
    <tr><td width=300>
        Select image to upload:</td><td>
        <input type="file" name="image" />       
        </td></tr>

        <tr><td>
        Store image to database
        </td><td>
          <input type="submit" name="submit_to_databse" value="DataBase"/>
        </td></tr>

        <tr><td>
        Store image  to folder
         </td><td>
          <input type="submit" name="submit_to_folder" value="Folder"/>
        </td></tr>

<tr><td>
        <input type="submit" name="View_From_Database" value="View Using DataBase"/>
         </td><td>
          <input type="submit" name="View_From_Folder" value="View Using Folder"/>
        </td></tr>

        </TABLE>
    </form>
</body>
</html>

<?php
if(isset($_SESSION['login_user']))
{
$user=$_SESSION['login_user'];
}
else
{

    header("Location: login.php");
}
if(isset($_POST["submit_to_databse"])){
  
  if($_FILES["image"]["name"])
    {
        
    $check = $_FILES['image']['size'];
 
    //$fileExtension = $_FILES['image']['name'];
      $imageFileType = strtoupper(pathinfo($_FILES["image"]["name"],PATHINFO_EXTENSION));
    if($check !== false){
      
        $image = $_FILES['image']['tmp_name'];          

       
        $imgContent = addslashes(file_get_contents($image)); 


 
if($imageFileType != "PDF" ) 
{
    

    echo " You have uploaded <b> " .$imageFileType ."  </b>file.</br> Sorry, only PDF files are allowed!!";
}
else
{
include_once 'config.php';     
            

        $conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
        
        // Check connection
       if (!$conn) {
           die("Connection failed: " . mysqli_connect_error());
        }
    
 $dataTime = date("Y-m-d H:i:s");
$sql = "INSERT into images (image, created,User_Name) VALUES ('$imgContent', '$dataTime','$user')"; 
$result = mysqli_query($conn, $sql); 
        
        
        if($result){
            echo "File uploaded successfully.";
        }else{
            echo "File upload failed, please try again.";
        } 
        
    }
    }
    else{
         echo " You have uploaded <b> " .$imageFileType ."  </b>file.</br> Sorry, only PDF files are allowed!!";
    }

   

}
    else{
        echo "Please select file to upload.";
    }
}
else if(isset($_POST["submit_to_folder"]))
{

if($_FILES["image"]["name"])
    {
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);
//$target_file_water=$target_dir . basename($_FILES["water"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    $check = getimagesize($_FILES["image"]["tmp_name"]);
   
    if($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
/*if ($_FILES["image"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}*/
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
} else {
        include_once 'config.php';     
            

        $conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
        
        // Check connection
       if (!$conn) {
           die("Connection failed: " . mysqli_connect_error());
        }
    $image_name=$_FILES["image"]["name"];

   
 $dataTime = date("Y-m-d H:i:s");
$sql = "INSERT into folder_images (created,image,User_Name) VALUES ('$dataTime','$image_name' ,'$user')"; 

$result = mysqli_query($conn, $sql);         
        
        if($result && move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
           echo "<div style=\" color:green;font-size:120%\">The file ". basename( $_FILES["image"]["name"]). " has been uploaded. </div>";

        }else{
            echo "File upload failed, please try again.";
        }        
   
}
}
else{
        echo "Please select file to upload.";
    }

}
else if(isset($_POST["View_From_Database"]))
{
         

 include_once 'config.php';     
            

        $conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
        
        // Check connection
       if (!$conn) {
           die("Connection failed: " . mysqli_connect_error());
        }
   
   
 
$sql = "SELECT created,id,image FROM images where User_Name='$user' "; 

$result = mysqli_query($conn, $sql);         

       if (mysqli_num_rows($result) > 0) {
     
        
echo "<table border='1'>
<tr>
<th>CREATED</th>
<th>ID</th>
<th>Image</th>
</tr>";

  while($row = mysqli_fetch_array($result)) 
{
echo "<tr>";
echo "<td>" . $row[0] . "</td>";
echo "<td>" . $row[1] . "</td>";

$a=base64_encode($row[2]);

echo "<td>" ."<img height=200 width=200 src='data:text/html;base64,".$a." '/>". "</td>";
echo "</tr>";
}
echo "</table>";

}
else
{
     echo "<div style=\"color:red;font-size:120%\">There are no record found. </div>";
}

        //Render image
      //  header("Content-type: image/jpg"); 
       // echo $imgData['image']; 
}


else if(isset($_POST["View_From_Folder"]))
{
include_once 'config.php';     
            

        $conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
        
        // Check connection
       if (!$conn) {
           die("Connection failed: " . mysqli_connect_error());
        }
   
   
 
$sql = "SELECT created,id,image FROM folder_images where User_Name='$user' "; 

$result = mysqli_query($conn, $sql);         

       if (mysqli_num_rows($result) > 0) {
     
        
echo "<table border='1'>
<tr>
<th>CREATED</th>
<th>ID</th>
<th>Image</th>
</tr>";

  while($row = mysqli_fetch_array($result)) 
{
echo "<tr>";
echo "<td>" . $row[0] . "</td>";
echo "<td>" . $row[1] . "</td>";


echo "<td><img src=uploads/".$row[2]." height=200 wigth=200 /></td>";
echo "</tr>";
}
echo "</table>";

}
else
{
     echo "<div style=\"color:red;font-size:120%\">There are no record found. </div>";
}

}
else
{

}

?>