 <?php
    if (isset($_POST['submit']))
        {     
    
   session_start();
    $username=$_POST['username'];
    $password=$_POST['password'];
   
        include_once 'config.php';
         
        //Create connection and select DB

       
       $conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
        
        // Check connection
       if (!$conn) {
           die("Connection failed: " . mysqli_connect_error());
        }
    

$sql = "SELECT User_Name FROM login_master WHERE Email='$username' and Password='$password'"; 
$result = mysqli_query($conn, $sql);

     if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
    
        $_SESSION['login_user']=$row["User_Name"];
    }

      echo "<script language='javascript' type='text/javascript'> location.href='home.php' </script>";        
      }
      else
      {
    echo "<script type='text/javascript'>alert('User Name Or Password Invalid!')</script>";
       }
mysqli_close($conn);
}



    
    ?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>

</head>
<body>
    <table align="center" bgcolor="#CCCCCC" border="0" cellpadding="0"
    cellspacing="1" width="300">
        <tr>
            <td>
                <form method="post" name="">
                    <table bgcolor="#FFFFFF" border="0" cellpadding="3"
                    cellspacing="1" width="100%">
                        <tr>
                            <td align="center" colspan="3"><strong>User
                            Login</strong></td>
                        </tr>
                        <tr>
                            <td width="78">Username</td>
                            <td width="6">:</td>
                            <td width="294"><input id="username" name=
                            "username" type="text" required placeholder="Enter a valid email address"></td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td>:</td>
                            <td><input id="password" name="password" type=
                            "password" required placeholder="Enter Password"></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td><input name="submit" type="submit" value=
                            "Login"> <input name="reset" type="reset" value=
                            "reset"></td>
                        </tr>
                    </table>
                </form>
            </td>
        </tr>
    </table>   
</body>
</html>