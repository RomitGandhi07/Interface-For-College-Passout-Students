 <html>
<head>
</head>
<body>
<?php
DATA FROM 
?>
<img src="printer.png" width="28" height="28" onclick="window.print()" />
<input type="button" value="Print this page" onclick="printpage()">
</body>
</html>