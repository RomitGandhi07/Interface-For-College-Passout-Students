<?php
include'dbconnection.php';
include("checklogin.php");


$q=mysqli_query($con,"update user_details set verification_status= 1 where user_id='".$_GET['upid']."'");

header("location:request.php");



?>