<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Small Modal</h2>
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Small Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-mm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>This is a small modal.</p>
		  	<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
					<div class="form-group">
                        <legend for="addline1" class="col-lg-12 control-label">Address</legend>
						<input type="text" name="addline1" id="first_name" class="form-control input-lg" placeholder="Flat No.,Building Name" tabindex="1">
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4" style="margin-top:5%">
					<div class="form-group">
					
						<input type="text" name="addline2" id="last_name" class="form-control input-lg" placeholder="Street,Colony" tabindex="2">
					</div>
				</div>
			</div>
			
			
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4" style="margin-top:1%">
					<div class="form-group">
                      
						<input type="text" name="landmark" id="first_name" class="form-control input-lg" placeholder="Landmark" tabindex="1">
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4" style="margin-top:1%">
					<div class="form-group">
					
						<input type="number" maxlength="6" name="pincode" id="last_name" class="form-control input-lg" placeholder="Pincode" tabindex="2">
					</div>
				</div>
			</div>
			
			
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4" style="margin-top:1%">
					<div class="form-group">
                      
						<input type="text" name="city" id="first_name" class="form-control input-lg" placeholder="City" tabindex="1">
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4" style="margin-top:1%">
					<div class="form-group">
					
						<input type="text" name="state" id="last_name" class="form-control input-lg" placeholder="State" tabindex="2">
					</div>
				</div>
			</div>
			
			
			
			
			<div class="col-sm-6 controls">
                
				<input type="submit" class="btn btn-success btn-signup" name="SignUp" value="SignUp" />
				</div>
		
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
