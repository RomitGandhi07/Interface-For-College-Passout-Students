$(document).ready(function(){
	$.ajax({
		url: "http://localhost/loginsystem/data.php",
		method: "GET",
		beginAtZero: true,
	
		success: function(data) {
			console.log(data);
			var RequestType = [];
			var Total = [];

			for(var i in data) {
				RequestType.push(data[i].RequestType);
				Total.push(data[i].Total);
			}

			var chartdata = {
				labels: RequestType,
				datasets : [
					{
						label: 'Application Chart',
						backgroundColor: 'rgba(200, 200, 200, 0.75)',
						borderColor: 'rgba(200, 200, 200, 0.75)',
						hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
						hoverBorderColor: 'rgba(200, 200, 200, 1)',
						data: Total
					}
				]
			};
			
			var options = {
    responsive: true,
    scales: {
        yAxes: [{
            display: true,
            ticks: {
                beginAtZero: true,
                max: 5,
                min: 0
            }
        }]
    },
};


			var ctx = $("#mycanvas");

			var barGraph = new Chart(ctx, {
				type: 'bar',
				data: chartdata,
				options: options
			});
		},
		error: function(data) {
			console.log(data);
		}
	});
});