<?php
	
session_start();
include'dbconnection.php';
include("checklogin.php");
check_login();
	 
	// echo "SELECT enrollment_no_proof FROM user_details WHERE user_id ='".$_GET['mid']."'"; 
	
	 $sql = "SELECT enrollment_no_proof FROM user_details WHERE user_id ='".$_GET['mid']."'"; 
	$result = mysqli_query($con,$sql);	
    
	while ($myrowsel = mysqli_fetch_array($result)) 
	{
        header("Content-Type: application/pdf");
        echo $myrowsel[enrollment_no_proof];
        exit();
	} 
	
	
?>