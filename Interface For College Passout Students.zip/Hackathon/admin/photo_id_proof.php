<?php
	
session_start();
include'dbconnection.php';
include("checklogin.php");
check_login();
	 
	/* echo "SELECT enrollment_no_proof FROM user_details WHERE user_id =".$_GET['pid']; */
	
	 $sql = "SELECT photo_id_proof FROM user_details WHERE user_id ='".$_GET['pid']."'"; 
	
	$result = mysqli_query($con,$sql);	
    
	while ($row = mysqli_fetch_array($result)) 
	{
        header("Content-Type: application/pdf");
        echo $row[photo_id_proof];
        exit();
	} 
	
	

	
?>