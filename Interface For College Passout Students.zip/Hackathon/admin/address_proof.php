<?php
session_start();
include'dbconnection.php';
include("checklogin.php");
check_login();

 $sql = "SELECT address_proof FROM user_details WHERE user_id ='".$_GET['adid']."'"; 
	
	$result = mysqli_query($con,$sql);	
    
	while ($row = mysqli_fetch_array($result)) 
	{
        header("Content-Type: application/pdf");
        echo $row[address_proof];
        exit();
	} 
	
	?>