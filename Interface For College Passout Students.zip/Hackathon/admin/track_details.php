<?php
session_start();
include'dbconnection.php';
include("checklogin.php");
check_login();
if(isset($_GET['uid']))
{
$_SESSION["r"]=$_GET['uid'];
}

if(isset($_GET['submit']))
{
	
	if(isset($_GET['delivery_status']))
	{
		//echo $_SESSION["r"];
		$st=$_GET['delivery_status'];
		if($st=="Pending")
		{
			$c=0;
		}
		else if($st=="approve")
		{
			$c=1;
		}
		else
		{
			$c=2;
		}
		
		//echo 
 $s=mysqli_query($con,"update application set track_no='".$_GET['trackid']."', courier_company='".$_GET['couriercom'] ."', delivery_status='".$c."' where user_id='".$_GET['uid']."'");
 
header("location:application.php"); 
}
else
{
	echo "no dp id";
}
}




?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Admin | Manage Users</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
  </head>

  <body>

  <section id="container" >
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <a href="#" class="logo"><b>Admin Dashboard</b></a>
            <div class="nav notify-row" id="top_menu">
               
                         
                   
                </ul>
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="#"><img src="assets/img/ui-sam.jpg" class="img-circle" width="60"></a></p>
              	  <h5 class="centered"><?php echo $_SESSION['login'];?></h5>
              	  	
                  <li class="mt">
                      <a href="change-password.php">
                          <i class="fa fa-file"></i>
                          <span>Change Password</span>
                      </a>
                  </li>
				   <li class="sub-menu">
                      <a href="bar.php">
                          <i class="fa fa-file"></i>
                          <span>graph</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="manage-users.php" >
                          <i class="fa fa-users"></i>
                          <span>Manage Users</span>
                      </a>
                   
                  </li>
				  
				  <li class="sub-menu">
                      <a href="university-details.php" >
                          <i class="fa fa-heart"></i>
                          <span>University Details</span>
                      </a>
                   
                  </li>
				  
				  <li class="sub-menu">
                      <a href="request.php" >
                          <i class="glyphicon glyphicon-envelope"></i>
                          <span>User Request </span>
                      </a>
                   
                  </li>
				   <li class="sub-menu">
                      <a href="application.php" >
                          <i class="glyphicon glyphicon-check"></i>
                          <span>Application </span>
                      </a>
                   
                  </li>
              
                 
              </ul>
          </div>
      </aside>
	  <form method="GET" action="">
      <section id="main-content">
          
		  <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Manage Users</h3>
				<div class="row">
				
                  
	                  
                  <div class="col-md-12">
                      <div class="content-panel">
                          <table class="table table-striped table-advance table-hover">
	                  	  	  <h4><i class="fa fa-angle-right"></i> All User Details </h4>
	                  	  	  <hr>
							
                              <thead>
                              
                              </thead>
                              <tbody>
							 
                               <tr>
							
                             <?php 
							 
							 
							 //echo "select * from application where user_id='".$_GET['uid']."'";
							 $ret=mysqli_query($con,"select * from application where user_id='".$_GET['uid']."'");
							  
							   $cnt=1;
							   
							  while($row=mysqli_fetch_array($ret))
							  {
								  echo "abc".$row[0];
							  ?>							 
							 <td><b> Sr no. </b> </td>
							 <td> <?php echo $cnt;?></td>
							 <tr>
							   <td><b> Email  </b></td>
							   <td>
							  <input type="text" width="300px" value="<?php echo $row["user_id"]; ?>" name="uid" readonly/> </td>
                                 </tr>
								 
								 <tr>
								 <td><b> Date </b></td>
								 <td><?php echo $row['Application_date'];?></td>
                                 </tr>
								 <tr>
								 <td><b> Request type </b></td>
								 <td><?php echo $row['request_type_id'];?></td>
                                  </tr>
								  <tr>
								  <td><b> Address id </b></td>
								  <td><?php echo $row['address_id'];?></td>
                                   </tr>
								   
								   <tr>
								   <td><b> Total </b></td>
								  <td><?php echo $row['total_amount'];?></td>  
								  </tr>
								  								  <tr>
								  <td><b> Payment status </b></td>
								  <td><?php echo $row['payment_status'];?></td>  
							     </tr>
								   <tr>
								  <td><b> Delivery Status </b></td>
								  
								  
								  <td> <select name="delivery_status">
                                   <option value="pending">Pending</option>
                                  <option value="approve">Approve</option>
                                  <option value="reject">Reject</option>
                                  </select> </td>  
							     </tr>

								  
						
							    
                                 
								  <tr> <td> IP Address </td> 
								  <td><?php echo $row["ip_address"]; ?> </td>
								  </tr>
                                 
							  
							  <?php $cnt=$cnt+1; }?>
							  <tr>
							  <td><b> Courier Company </b></td>
							  <td><input type="text" width="30" name="couriercom"> </textarea ></td>
							  
							  </tr>
							 <tr>
							 <td> <b> Track id <b></td>
							 <td><input type="text" width="30" name="trackid"> </textarea ></td> </tr>
							  </tr> 
							  <tr>
							  <td> </td>
							  <td>
							 <input type="submit" name="submit" class="btn btn-success"  value="submit"/></td> </tr>
							        
								  
                                  
                                  
                             
                             
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
		</section>
		
      </section>
	  </form>
	  </section>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/common-scripts.js"></script>
  <script>
      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
