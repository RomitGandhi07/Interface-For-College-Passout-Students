<?php 
$con=mysqli_connect("localhost","root","","finaldatabae");
//$s=$_POST[''];

?>